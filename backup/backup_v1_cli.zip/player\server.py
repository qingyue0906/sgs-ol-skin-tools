#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
三国杀OL 动皮播放器本地服务器（纯标准库）

提供:
  /player/          播放器页面
  /output/skins/    动皮资源（静态）
  /api/skins        皮肤列表 JSON（含 daiji.json 的可播放皮肤）
  /api/skin/{id}    某个皮肤的文件列表 JSON

用法:  python player/server.py [--port 8123]
"""
import argparse
import json
import re
import socket
import sys
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKINS = ROOT / "output" / "skins"


def port_in_use(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("127.0.0.1", port))
        return False
    except OSError:
        return True
    finally:
        s.close()


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def _json(self, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/api/skins":
            skins = []
            if SKINS.is_dir():
                for d in sorted(SKINS.iterdir()):
                    if d.is_dir() and (d / "daiji.json").exists():
                        skins.append(d.name)
            self._json({"skins": skins})
            return
        m = re.match(r"^/api/skin/(\d+)$", path)
        if m:
            d = SKINS / m.group(1)
            files = sorted(p.name for p in d.iterdir() if p.is_file()) if d.is_dir() else []
            self._json({"id": m.group(1), "files": files})
            return
        super().do_GET()


def main():
    ap = argparse.ArgumentParser(description="动皮播放器本地服务器")
    ap.add_argument("--port", type=int, default=8123)
    ap.add_argument("--no-browser", action="store_true", help="不自动打开浏览器")
    args = ap.parse_args()
    url = "http://127.0.0.1:%d/player/" % args.port
    if port_in_use(args.port):
        print("端口 %d 已被占用，可能已有播放器服务器在运行。" % args.port, flush=True)
        print("请关闭占用该端口的进程后重试，或改用 --port 指定其他端口。", flush=True)
        return 1
    server = HTTPServer(("127.0.0.1", args.port), Handler)
    server.allow_reuse_address = False
    print("=" * 50, flush=True)
    print("三国杀OL 动皮播放器服务器", flush=True)
    print("页面地址: %s" % url, flush=True)
    print("关闭本窗口（或按 Ctrl+C）即可停止服务", flush=True)
    print("=" * 50, flush=True)
    if not args.no_browser:
        try:
            import webbrowser
            webbrowser.open(url)
        except Exception:
            pass
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("服务器已停止", flush=True)
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    if not sys.stdout.isatty():
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
            sys.stderr.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    sys.exit(main())